//import hero from "../assets/hero-placeholder.jpg" // reemplaza por imagen real cuando la tengas
// Si aún no tienes imagen, puedes comentar la línea y usar el bloque de gradiente

export default function Inicio() {
    const sections = [
        {
        id: "que-hacemos",
        title: "¿Qué hacemos?",
        desc:
            "Impulsamos el desarrollo integral de niños, jóvenes y familias a través de programas educativos, culturales, sociales y de bienestar.",
        badge: "✨",
        },
        {
        id: "compromiso-social",
        title: "Compromiso social",
        desc:
            "Trabajamos con comunidades de Colombia y el mundo, promoviendo solidaridad, equidad y oportunidades con enfoque humano.",
        badge: "🤝",
        },
        {
        id: "programas",
        title: "Programas",
        desc:
            "Refuerzo escolar, artes y danza, iniciación musical, mercados, BESPRO, apadrinamiento y más. Conócelos en detalle en la página de Programas.",
        badge: "📚",
        link: { href: "/programas", label: "Ver Programas" },
        },
        {
        id: "espiritualidad",
        title: "Espiritualidad y Sanación pránica",
        desc:
            "Inspirados en la enseñanza de G.M.C.K.S, promovemos prácticas de meditación y sanación pránica para el bienestar físico, emocional y espiritual.",
        badge: "🕊️",
        },
        {
        id: "servicios",
        title: "Servicios",
        desc:
            "Campañas de salud, jornadas deportivas, espirituales y recreativas con profesionales nacionales e internacionales que desean servir.",
        badge: "💠",
        link: { href: "/servicios", label: "Conoce nuestros Servicios" },
        },
    ]

    return (
        <main className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-rose-50">
        {/* HERO */}
        <section className="relative overflow-hidden">
            {/* Fondo decorativo */}
            <div aria-hidden className="pointer-events-none absolute inset-0">
            <div className="absolute -top-24 -left-24 w-80 h-80 rounded-full bg-pink-300/30 blur-3xl" />
            <div className="absolute -bottom-24 -right-24 w-96 h-96 rounded-full bg-orange-300/30 blur-3xl" />
            </div>

            <div className="max-w-7xl mx-auto px-4 md:px-6 py-12 md:py-16 grid grid-cols-1 lg:grid-cols-12 gap-8 relative">
            {/* Contenido */}
            <div className="lg:col-span-6 flex flex-col justify-center text-center lg:text-left">
                <h1 className="text-4xl md:text-5xl font-black leading-tight">
                <span className="text-pink-600">Fundación Atma Namasté</span>
                <br />
                <span className="text-sky-600">sanación pránica G.M.C.K.S</span>
                </h1>
                <p className="mt-4 text-lg text-gray-700">
                Apoyamos a la comunidad con programas educativos, de bienestar y sanación pránica. ¡Conócenos!
                </p>
            </div>

            {/* Imagen representativa centrada (en desktop queda a la derecha, en mobile centrada) */}
            <div className="lg:col-span-6 flex items-center justify-center">
                {/* Si aún no tienes imagen, puedes mostrar el marco con degradé */}
                <div className="relative w-full max-w-md aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl border border-white/60 bg-gradient-to-br from-pink-200 via-rose-100 to-orange-100">
                {/* Imagen real (descomenta cuando tengas asset) */}
                {/* <img
                    src={hero}
                    alt="Fundación Atma Namasté"
                    className="w-full h-full object-cover"
                /> */}
                {/* Marca de agua ligera */}
                <div className="absolute inset-0 grid place-items-center">
                    <span className="text-pink-500/70 font-semibold">Imagen representativa</span>
                </div>
                </div>
            </div>
            </div>
        </section>

        {/* SECCIONES DESTACADAS */}
        <section className="max-w-7xl mx-auto px-4 md:px-6 pb-16">
            <div className="grid grid-cols-1 gap-8">
            {sections.map((s, idx) => (
                <article
                id={s.id}
                key={s.id}
                className={[
                    "relative rounded-3xl bg-white/80 backdrop-blur-sm",
                    "border border-white/60 shadow-sm hover:shadow-md transition-shadow",
                    "p-6 md:p-8",
                ].join(" ")}
                >
                {/* Badge decorativa */}
                <div className="absolute -top-4 left-6 inline-flex items-center justify-center w-10 h-10 rounded-full bg-pink-500 text-white shadow-md text-lg">
                    {s.badge}
                </div>

                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                    {/* Texto */}
                    <div className="flex-1">
                    <h2 className="text-2xl md:text-3xl font-bold text-pink-700">{s.title}</h2>
                    <p className="mt-3 text-gray-700">{s.desc}</p>

                    {s.link && (
                        <div className="mt-5">
                        <a
                            href={s.link.href}
                            className="inline-flex items-center gap-2 text-pink-700 font-semibold hover:text-pink-800"
                        >
                            {s.link.label}
                            <svg
                            className="w-5 h-5"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                            aria-hidden="true"
                            >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                            </svg>
                        </a>
                        </div>
                    )}
                    </div>

                    {/* “Ilustración” lateral minimalista por sección (no imagen pesada, estilo coherente) */}
                    <div className="w-full lg:w-72">
                    <div className="relative aspect-[4/3] rounded-2xl border border-pink-200 bg-gradient-to-br from-pink-50 to-rose-50 overflow-hidden">
                        <div className="absolute -top-10 -left-10 w-40 h-40 rounded-full bg-pink-300/40 blur-2xl" />
                        <div className="absolute -bottom-10 -right-10 w-40 h-40 rounded-full bg-orange-300/40 blur-2xl" />
                        <div className="absolute inset-0 grid place-items-center">
                        <span className="text-pink-500/70 font-medium">Imagen alusiva</span>
                        </div>
                    </div>
                    </div>
                </div>
                </article>
            ))}
            </div>
        </section>

        {/* CTA suave al final (opcional) */}
        <section className="pb-20">
            <div className="max-w-4xl mx-auto px-4 md:px-6">
            <div className="rounded-3xl bg-pink-100/70 border border-white/60 shadow-sm p-8 md:p-10 text-center">
                <h3 className="text-2xl md:text-3xl font-bold text-pink-700">¿Quieres saber más?</h3>
                <p className="mt-2 text-gray-700">
                Súmate a nuestra misión y acompáñanos en actividades sociales, educativas y espirituales.
                </p>
                <div className="mt-6 flex items-center justify-center gap-4">
                <a
                    href="/contacto"
                    className="inline-flex items-center px-5 py-3 rounded-xl bg-pink-500 text-white font-semibold hover:bg-pink-600 transition-colors"
                >
                    Contáctanos
                </a>
                <a
                    href="/programas"
                    className="inline-flex items-center px-5 py-3 rounded-xl text-pink-700 font-semibold border border-pink-300 hover:bg-pink-50 transition-colors"
                >
                    Ver Programas
                </a>
                </div>
            </div>
            </div>
        </section>
        </main>
    )
}
